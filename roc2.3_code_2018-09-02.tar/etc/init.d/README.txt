NOTE: When you run the makefile it will copy the scripts in this
directory to /etc/init.d. If this is the first time you are installing
these scripts then you must also generate links to these scripts in
the various run-level directories using the update-rc.d utility.

